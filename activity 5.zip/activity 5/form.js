function verifyPassword() {  
    var pw = document.getElementById("password").value;  
    
    if(pw == "") {  
       document.getElementById("message").innerHTML
      
       return false;  
    }  
     
    
    if(pw.length < 6) {  
       document.getElementById("message").innerHTML  
       return false;  
    }  
    
    
    if(pw.length > 20) {  
       document.getElementById("message").innerHTML 
       return false;  
    } else {  
       alert("Password is correct");  
    }  
  }  